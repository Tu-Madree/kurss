﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _1.FormsPoint
{
    /// <summary>
    /// Логика взаимодействия для WinPoint.xaml
    /// </summary>
    public partial class WinPoint : Window
    {
        public void Update()
        {
           var query = EntitiesFlowers.GetContext().Point.ToList();
            dgPoint.ItemsSource = query;
        }
        public WinPoint()
        {
            InitializeComponent();
            Update();
        }

        private void dgPoint_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var pointDelected = dgPoint.SelectedItems.Cast<Point>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить след. {pointDelected.Count()} элементов?", "Внимание!!!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    EntitiesFlowers.GetContext().Point.RemoveRange(pointDelected);
                    EntitiesFlowers.GetContext().SaveChanges();
                    MessageBox.Show("данные удалены");
                }
                catch
                {
                    MessageBox.Show("Ошибка удаления данных");
                }

            }
        }
    }
}
