﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _1.Forms
{
    /// <summary>
    /// Логика взаимодействия для WinAdd.xaml
    /// </summary>
    public partial class WinAdd : Window
    {
        private Product _product = new Product();

        public WinAdd(Product selectedProduct)
        {
            InitializeComponent();
            var category = EntitiesFlowers.GetContext().Product.Select(p => p.ProductCategory).ToList();
            category.Insert(0, "Все категории");
            cmbCategory.ItemsSource = category.Distinct();

            var manufF = EntitiesFlowers.GetContext().Product.Select(p => p.ProductManufacturer).ToList();
            manufF.Insert(0, "Все производители");
            cmbManufacture.ItemsSource = manufF.Distinct();

            var privider = EntitiesFlowers.GetContext().Product.Select(p => p.ProductPrivider).ToList();
            privider.Insert(0, "Все поставщики");
            cmbPrivider.ItemsSource = privider.Distinct();

            if (selectedProduct != null)
            {
                _product = selectedProduct;
            }


            DataContext = _product;
        }

        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            //заполн полей
            if (string.IsNullOrWhiteSpace(_product.ProductArticleNumber))
            {
                error.AppendLine("Укажите артикул");
            }
            if(!_product.ProductCost.ToString().All(char.IsDigit))
            {
                error.AppendLine("Цена должна быть числом");
            }

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если продукта не сущ, то дабовл новый
            if (!EntitiesFlowers.GetContext().Product.Select(p=>p.ProductArticleNumber).Contains(_product.ProductArticleNumber))
            {
                EntitiesFlowers.GetContext().Product.Add(_product);
            }


            //сохр в табл
            try
            {
           
            EntitiesFlowers.GetContext().SaveChanges();
            MessageBox.Show("Данные добавлены");
            }
            catch
            {
                MessageBox.Show("Ошибка добавления в базу");
            }
            
        }
    }
}
